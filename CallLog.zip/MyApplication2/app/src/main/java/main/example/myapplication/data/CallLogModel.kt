package main.example.myapplication.data

import java.time.Duration

class CallLogModel (val name: String, val number: String, val dateTime: String, val duration: String,
     val type: String) {
}